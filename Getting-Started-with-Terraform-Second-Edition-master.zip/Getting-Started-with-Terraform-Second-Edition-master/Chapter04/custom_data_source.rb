require 'json'
data = {
  owner: "Packt"
}
puts data.to_json
