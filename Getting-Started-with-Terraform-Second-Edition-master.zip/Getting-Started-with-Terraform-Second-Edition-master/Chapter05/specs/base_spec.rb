describe package('wget') do
  it { should be_installed }
end
